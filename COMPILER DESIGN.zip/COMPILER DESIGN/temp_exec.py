def two_sum(nums, target):
    num_map = {}
    for index, num in enumerate(nums):
        complement = target - num
        if complement in num_map:
            print([num_map[complement], index])
            return
        num_map[num] = index
    print("No two sum solution exists.")

nums = [2, 7, 11, 15]
target = 9
two_sum(nums, target)

nums = [3, 2, 4]
target = 6
two_sum(nums, target)

nums = [3, 3]
target = 6
two_sum(nums, target)

nums = [1, 2, 3, 4, 5]
target = 10
two_sum(nums, target)

nums = [1, 2, 3, 4, 5]
target = 7
two_sum(nums, target)

nums = [1, 2, 3, 4, 5]
target = 1
two_sum(nums, target)


